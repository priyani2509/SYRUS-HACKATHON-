# ImpactRadar website prototype

Open `index.html` in any modern browser.

This is a front-end POC based on the ImpactRadar PPT:
- opportunity discovery
- multi-source/agent framing
- eligibility vs relevance
- explainable match scores
- filters
- saved opportunities
- change-monitoring notifications
- SDG 4 / 10 / 13 mapping
- AI guardrail: missing requirements remain “Not specified”

The event data is demo data; no real APIs or LLM calls are connected in this front-end prototype.
